# Variable names should express the purpose
first_name = "Russell"
num1 = 10
num2, num3 = 20, 30
print(first_name)

print(num1)
print(num2)
print(num3)

print(id(first_name))
print(id(num1))
# del first_name
print(type(first_name))

"""
name = input("Type your name :")
print("My name is " + name)

"""