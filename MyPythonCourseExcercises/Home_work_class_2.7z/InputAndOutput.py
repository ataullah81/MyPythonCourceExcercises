num = input("Enter a number : ")
print("You entered number : " + num)
print(type(num))

# Data type casting
num1 = int(num)  #Saved in a memory location
print("After conversion: ")
print(type(num1))

first_name = input("Enter your firstname : ")
last_name = input("Enter your lastname : ")
age = input("Enter your age : ")

print("Your name is : " + first_name +" "+ last_name)
print ("You are : " + age + " years old")