"""
Numeric -> Integer, Float, Complex Number
Dictionary
Boolean - True/False
Set
Sequence Type -> Strings, List, Tuple

"""

number_1 = 20
print(type(number_1))  #Int
print("Memory location is : ") # How can use single line print command to print memory location?
print(id(number_1))

number_2 = 30.4
print(type(number_2)) #Float
print(id(number_2)) 

name = "Russell"
print(type(name)) #Str
print(id(name))